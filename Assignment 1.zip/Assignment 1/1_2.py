# Input two numbers
a = float(input("Enter the first number: "))
b = float(input("Enter the second number: "))

# Swap the numbers
a, b = b, a

# Print the swapped numbers
print(f"After swapping, the first number is: {a}")
print(f"After swapping, the second number is: {b}")
