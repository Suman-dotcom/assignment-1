# Input temperature in Fahrenheit
fahrenheit = float(input("Enter temperature in Fahrenheit: "))

# Convert to Celsius
celsius = (fahrenheit - 32) * 5/9

# Print the result
print(f"{fahrenheit} Fahrenheit is equal to {celsius} Celsius")
