# Input temperature in Celsius
celsius = float(input("Enter temperature in Celsius: "))

# Convert to Fahrenheit
fahrenheit = (celsius * 9/5) + 32

# Print the result
print(f"{celsius} Celsius is equal to {fahrenheit} Fahrenheit")
