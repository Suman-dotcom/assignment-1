# Input a number
num = float(input("Enter a number: "))

# Check if the number is positive or negative
if num > 0:
    print(num, "is positive")
elif num < 0:
    print(num, "is negative")
else:
    print(num, "is zero")
