name = input("Enter your name : ")
print("Your name is ",name)