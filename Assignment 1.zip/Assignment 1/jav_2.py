# Input two numbers
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))

# Calculate the sum
sum = num1 + num2

# Print the result
print("The sum of", num1, "and", num2, "is", sum)
