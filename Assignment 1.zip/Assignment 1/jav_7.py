# Input a number
num = int(input("Enter a number: "))

# Check if the number is odd or even
if num % 2 == 0:
    print(num, "is even")
else:
    print(num, "is odd")
