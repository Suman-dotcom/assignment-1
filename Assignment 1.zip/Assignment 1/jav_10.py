# Input two numbers
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))

# Swap the numbers
num1, num2 = num2, num1

# Print the results
print("After swapping:")
print("First number:", num1)
print("Second number:", num2)
