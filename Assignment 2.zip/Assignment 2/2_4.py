import math

a = 5**8
b = math.sqrt(400)
c = math.exp(5)
d = math.log(625,5)

print(f"a) 5 to the power of 8 = {a}")
print(f"b) square root of 400 = {b}")
print(f"c) exponent of 5 = {c}")
print(f"d) logarith of 625 base 5 = {d}")

