import math

a = float(input("Enter 1st number : "))
b = float(input("Enter 2nd number : "))
c = float(input("Enter 3rd number : "))

sum = math.sqrt(a) + math.sqrt(b) + math.sqrt(c)

print(f"Sum of square roots of {a}, {b} and {c} = {sum}")