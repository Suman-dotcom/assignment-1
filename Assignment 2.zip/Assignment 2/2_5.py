import math

a = math.sin(math.radians(60))
b = math.cos(math.pi)
c = math.sin(0.8660254037844386)
d = math.tan(math.radians(90))

print(f"a) sin(60 degrees) = {a}")
print(f"b) cos(pi) = {b}")
print(f"c) sin(0.8660254037844386) = {c}")
print(f"d) tan(90 degrees) = {d}")

