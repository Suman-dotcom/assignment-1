result = 1
i=12
while i != 0 :
    result *= i
    i-=1

print(f"Factorial of 12 = {result}")