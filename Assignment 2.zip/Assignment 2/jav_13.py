percent = float(input("Enter your percentage : "))

if percent >= 90 :
    print("Grade A")
elif percent >= 80 :
    print("Grade B")
elif percent >= 70 :
    print("Grade C")
elif percent >= 60 :
    print("Grade D")
elif percent >= 40 :
    print("Grade E")
else :
    print("Grade F")

