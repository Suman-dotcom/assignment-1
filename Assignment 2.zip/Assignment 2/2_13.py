count = 1
result = 2
print(f"{result} ", end = '')

while count <= 5:
    result *= 3
    print(f"{result} ", end = '')
    count+=1
    