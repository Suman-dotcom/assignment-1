miles = float(input("Enter distance in Miles : "))
print(f"{miles} Miles = {miles * 1.60934} Kilometres")