def sum (n1,n2) :
    return (n1 + n2)

num1 = int(input("Enter 1st number : "))
num2 = int(input("Enter 2nd number : "))
print(f"Sum of {num1} and {num2} = {sum(num1,num2)}")